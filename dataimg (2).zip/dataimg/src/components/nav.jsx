import React from 'react';
function Navbar(props) {
    return (
<nav className="navbar">
  <span className="navbar-brand mb-0 h1"><b>SECQUR <span style={{color:"red"}}>AI</span>SE</b></span>
</nav>
    );
}

export default Navbar;
